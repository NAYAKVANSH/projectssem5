import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sb
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from xgboost import XGBClassifier
from sklearn import metrics
import warnings
warnings.filterwarnings('ignore')

# Importing Dataset
df = pd.read_csv('stock_data.csv')
df['Date'] = pd.to_datetime(df['Date'])  # Convert 'Date' to datetime type
df.head()

# Exploratory Data Analysis
plt.figure(figsize=(15, 5))
plt.plot(df['Close'])
plt.title('Tesla Close price.', fontsize=15)
plt.ylabel('Price in dollars.')
plt.show()

# Checking for redundant data and dropping the 'Adj Close' column if it exists
if 'Adj Close' in df.columns:
    df = df.drop(['Adj Close'], axis=1)  # Dropping 'Adj Close' column

# Checking for null values
print(df.isnull().sum())

# Distribution plot for continuous features
numeric_features = ['Open', 'High', 'Low', 'Close', 'Volume']
plt.subplots(figsize=(20, 10))
for i, col in enumerate(numeric_features):
    plt.subplot(2, 3, i+1)
    sb.distplot(df[col])
plt.show()

# Boxplot for continuous features
plt.subplots(figsize=(20, 10))
for i, col in enumerate(numeric_features):
    plt.subplot(2, 3, i+1)
    sb.boxplot(df[col])
print(df.columns)

# Adding a 'year' feature for quarterly analysis
df['year'] = df['Date'].dt.year

# Grouping data by year and plotting average OHLC values
data_grouped = df.groupby('year').mean()
plt.subplots(figsize=(20, 10))
for i, col in enumerate(['Open', 'High', 'Low', 'Close']):
    plt.subplot(2, 2, i+1)
    data_grouped[col].plot.bar()
plt.show()

print(df.head())
